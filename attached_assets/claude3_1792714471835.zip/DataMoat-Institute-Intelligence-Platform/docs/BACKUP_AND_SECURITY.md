# Backup, recovery, security and model governance

## Backups (PostgreSQL)

Back up daily and before every migration or model change.

```powershell
pg_dump -U datamoat -h localhost -Fc -f datamoat_YYYYMMDD.dump datamoat
```

Restore into a new, empty database (never over the live one without a fresh backup):

```powershell
createdb -U postgres datamoat_restore
pg_restore -U datamoat -h localhost -d datamoat_restore --no-owner datamoat_YYYYMMDD.dump
```

Store dumps encrypted, off the machine, with limited access. Test a restore at least once per term. Dumps contain student records and password hashes.

## Security checklist

- Run on `127.0.0.1` or a private network or VPN; never expose PostgreSQL publicly.
- Strong `SESSION_SECRET` and database password, kept in `.env`, never committed (`.env` is in `.gitignore`).
- Authorization is enforced in backend functions (Owner checks, institute scoping), not only by hiding menus.
- Credentials files: download once, hand out per student, delete afterwards. Passwords are not logged or stored in plain text.
- Audit log records account creation, resets, password changes and stored predictions, without secrets.
- Review accounts regularly and deactivate leavers.

## Retention and deletion

Keep student data only as long as the institute needs it. Use Privacy > clear academic data for bulk removal, and delete
accounts of former students. Prediction rows cascade-delete with their student.

## Model update and rollback

1. Back up the database.
2. Retrain only when enough new labelled departures exist; check the validation gate.
3. Compare the new test PR-AUC, Brier score and calibration plot with the stored previous version.
4. Save predictions (each run is keyed by model version and data cutoff, so old runs stay intact).
5. To roll back, stop using the newer `model_version` rows; they remain stored for comparison. After each window passes, record the actual outcome (`outcome` column) to monitor real performance.

## Responsible use

Predictions support human review only. Never use them to penalise, exclude or deny opportunities. Avoid collecting
sensitive attributes you do not need. Check error rates across groups once enough real data and governance exist.
