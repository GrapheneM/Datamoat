"""Create or update the local development schema. Run manually, never at app startup."""

from sqlalchemy import text

from .db import get_engine
from .models import Base


def main() -> None:
    engine = get_engine()
    Base.metadata.create_all(engine)
    # create_all never alters existing tables, so add newer columns explicitly.
    with engine.begin() as connection:
        connection.execute(
            text(
                "ALTER TABLE dm_users ADD COLUMN IF NOT EXISTS "
                "must_change_password BOOLEAN NOT NULL DEFAULT FALSE"
            )
        )
    print("DataMoat schema is ready.")


if __name__ == "__main__":
    main()
