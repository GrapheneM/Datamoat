# DataMoat

Institute-intelligence app for small educational institutes. Python, Streamlit, PostgreSQL, SQLAlchemy, pandas, scikit-learn.
It helps an Owner see academic performance, attendance, engagement and fees, and identify students who may benefit from support.

## Features

| Area | What it does |
|---|---|
| Accounts | Institute-scoped Owner, Teacher, Student, Parent accounts. Argon2 password hashes, lockout after repeated failures, audit log. Owner-created and reset passwords must be changed at first sign-in. |
| Bulk student accounts | Owner uploads a CSV (`student_id`, optional `login_id`). A dry run lists every bad row; creation is all-or-nothing; temporary passwords are random, shown once, never stored in plain text. |
| Data imports | CSV or XLSX for students, questions, tests, responses, attendance, fees, engagement, with validation and cross-reference checks. |
| Analytics | Overview, topic mastery, early warning (rule-based support score), percentile range, parent reports, owner-only economics. |
| Departure risk | Trained logistic-regression estimate of P(student leaves within N days), calibrated and evaluated on a later held-out period, compared with the rule-based score. Owner only. |
| Graphs | Interactive Plotly heatmaps for attendance, topic mastery, support bands, student signals, feature deviations, confusion matrix; calibration, probability and coefficient charts. |

## Setup (Windows / PyCharm)

1. Install Python 3.12+ and PostgreSQL. Create an empty database named `datamoat` and a user for it.
2. Open the project folder in PyCharm and create a virtual environment (Settings > Project > Python Interpreter).
3. In the PyCharm terminal:

```powershell
pip install -r requirements.txt
copy .env.example .env
```

4. Edit `.env`: set `DATABASE_URL` (for example `postgresql+psycopg://datamoat:YOURPASSWORD@localhost:5432/datamoat`) and a long random `SESSION_SECRET`.
   Generate one with `python -c "import secrets; print(secrets.token_urlsafe(48))"`.
5. Create or update the schema (safe to re-run; run it after every update):

```powershell
python -m datamoat.migrate
```

6. Start the app:

```powershell
$env:STREAMLIT_SERVER_COOKIE_SECRET = "<same value as SESSION_SECRET>"
streamlit run app.py --server.address 127.0.0.1 --server.port 5000
```

macOS/Linux: `STREAMLIT_SERVER_COOKIE_SECRET="$SESSION_SECRET" streamlit run app.py --server.address 127.0.0.1 --server.port 5000`.

7. Open the app, choose **Create an institute**, and create the first Owner. There are no demo credentials.

Keep the app on `127.0.0.1` or a private network. Do not expose PostgreSQL to the internet.

## Import order

1. Students (include `dropout_date` for anyone who has withdrawn)
2. Questions
3. Tests
4. Test responses
5. Optional: attendance, fees, engagement
6. Then create student accounts (User access)

Imports are validated before saving; an invalid file leaves the database unchanged.

## Student accounts: recommended workflow

1. User access > Bulk create > download the template of students without accounts.
2. Optionally edit `login_id` (blank = the student ID). Upload it. Fix any problems listed.
3. Create accounts and download the credentials file immediately. It contains `institute_id`, `login_id` and a temporary password.
4. Give each student only their own row, privately. Delete the file afterwards.
5. Each student sets a new password at first sign-in.

## Departure risk model

The page runs automatically when opened (cached for 10 minutes and refreshed when data changes). With too few recorded
withdrawals to train a model it shows a rule-based support watchlist instead and a progress indicator toward the data needed.

Estimates `P(student leaves within the next N days | data known today)` (default N = 60, configurable).

- **Label:** `dropout_date` inside (snapshot, snapshot + N] is 1. Stayed through a fully observed window is 0. Students whose window is not finished are censored and excluded from training, never counted as "stayed".
- **Snapshots:** every 14 days per student, features use only data on or before that date: attendance (7/14/30 days, trend, consecutive absences), tests (overall, recent, slope), homework, logins, doubts, days since activity, tenure, and optional fee timing. Missing data stays missing (median-imputed), it is never zero and never treated as risk.
- **Split:** chronological train / validation / test with an N-day purge gap, so label windows never straddle periods.
- **Model:** regularised logistic regression (strength picked on validation). Gradient boosting is shown for comparison only.
- **Calibration and threshold:** Platt calibration and the review threshold are fitted on validation only. The threshold maximises recall-weighted F2 subject to the share of students you can follow up.
- **Validation gate:** shown as validated only with at least 20 / 5 / 10 departures in train / validation / test, successful calibration, and test PR-AUC above the base rate. Otherwise the page states it is exploratory.
- **Use:** supports a private, supportive check-in. Never use it for penalties, exclusion or denial of opportunity. Listed factors are associations, not causes.

Limits: students with no recorded `dropout_date` are assumed to have stayed. If withdrawals are not recorded reliably, results are unreliable. The synthetic Northstar data demonstrates the pipeline only; it says nothing about real accuracy. Group-level fairness checks need enough real data and governance and are not automated yet.

Predictions can be saved to `dm_predictions` (model version, window, data cutoff, probability, validated flag).

## Economics

`economic_summary` reports, as of the reporting cutoff: scheduled (instalments due), collected (paid on or before the cutoff), overdue (due and unpaid at the cutoff). Collected plus overdue equals scheduled. A payment made after the cutoff no longer counts as collected for that cutoff (fixed in this release; it previously did). If you keep a separate economics spreadsheet, compare its assumptions before treating the two as equivalent.

## Tests

```powershell
pip install pytest
python -m pytest tests
```

- `tests/test_attrition.py`: labels, censoring, no future data in features, chronological split, metrics, thresholds, empty and tiny data (synthetic fixture).
- `tests/test_economics_analytics.py`: fee totals and cutoff handling, rule-based baseline, missing data is not risk.
- `tests/test_accounts_db.py`: bulk creation, rollback, hashing, forced password change. Skipped unless `TEST_DATABASE_URL` points to a disposable PostgreSQL database.

Passing synthetic tests shows the code works, not that the model predicts real departures.

## More

- `docs/BACKUP_AND_SECURITY.md`: backup, restore, retention, security checklist, model update and rollback.
- `replit.md`: Replit-specific notes.
